
package Vista;
import controlador.ExpansionDAO;
import controlador.JuegoDAO;
import javax.swing.JOptionPane;


public class Ingresar extends javax.swing.JFrame {

    
    public Ingresar() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        MenuBar1 = new javax.swing.JMenuBar();
        IngresarMenu = new javax.swing.JMenu();
        jIngresarJuegoItem = new javax.swing.JMenuItem();
        jIngresarExpansionItem = new javax.swing.JMenuItem();
        InformacionMenu = new javax.swing.JMenu();
        jMostrarJuegosItem = new javax.swing.JMenuItem();
        jMostrarExpansionItem = new javax.swing.JMenuItem();
        btnStocktotalEX = new javax.swing.JMenu();
        btnStockjuegos = new javax.swing.JMenuItem();
        btnStockexpansiones = new javax.swing.JMenuItem();
        SalirMenu = new javax.swing.JMenu();
        jSalirAplicacionItem = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/dragon-logo-89D2DDF90F-seeklogo.com.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 140, -1, -1));

        jLabel2.setFont(new java.awt.Font("Viner Hand ITC", 1, 60)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Tienda LolGames");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 50, -1, -1));

        MenuBar1.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        IngresarMenu.setText("Ingresar");
        IngresarMenu.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jIngresarJuegoItem.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jIngresarJuegoItem.setText("Ingresar juego");
        jIngresarJuegoItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jIngresarJuegoItemActionPerformed(evt);
            }
        });
        IngresarMenu.add(jIngresarJuegoItem);

        jIngresarExpansionItem.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jIngresarExpansionItem.setText("Ingresar expansion");
        jIngresarExpansionItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jIngresarExpansionItemActionPerformed(evt);
            }
        });
        IngresarMenu.add(jIngresarExpansionItem);

        MenuBar1.add(IngresarMenu);

        InformacionMenu.setText("Informacion");
        InformacionMenu.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jMostrarJuegosItem.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jMostrarJuegosItem.setText("Mostrar juegos");
        jMostrarJuegosItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMostrarJuegosItemActionPerformed(evt);
            }
        });
        InformacionMenu.add(jMostrarJuegosItem);

        jMostrarExpansionItem.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jMostrarExpansionItem.setText("Mostrar expansiones");
        jMostrarExpansionItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMostrarExpansionItemActionPerformed(evt);
            }
        });
        InformacionMenu.add(jMostrarExpansionItem);

        MenuBar1.add(InformacionMenu);

        btnStocktotalEX.setText("Estadisticas");
        btnStocktotalEX.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        btnStockjuegos.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnStockjuegos.setText("Stock total de juegos");
        btnStockjuegos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStockjuegosActionPerformed(evt);
            }
        });
        btnStocktotalEX.add(btnStockjuegos);

        btnStockexpansiones.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnStockexpansiones.setText("Stock total de expansiones ");
        btnStockexpansiones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStockexpansionesActionPerformed(evt);
            }
        });
        btnStocktotalEX.add(btnStockexpansiones);

        MenuBar1.add(btnStocktotalEX);

        SalirMenu.setText("Salir");
        SalirMenu.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jSalirAplicacionItem.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jSalirAplicacionItem.setText("Salir de la aplicacion");
        jSalirAplicacionItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jSalirAplicacionItemActionPerformed(evt);
            }
        });
        SalirMenu.add(jSalirAplicacionItem);

        MenuBar1.add(SalirMenu);

        setJMenuBar(MenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 850, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 510, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jIngresarJuegoItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jIngresarJuegoItemActionPerformed
        IngresarJuego ventIn=new IngresarJuego();
        ventIn.setLocationRelativeTo(null);
        ventIn.setTitle("INGRESO DE DATOS DEL JUEGO");
        ventIn.setResizable(false);
        ventIn.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        ventIn.setVisible(true);
    }//GEN-LAST:event_jIngresarJuegoItemActionPerformed

    private void jIngresarExpansionItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jIngresarExpansionItemActionPerformed
        IngresarExpansion ventIn=new IngresarExpansion();
        ventIn.setLocationRelativeTo(null);
        ventIn.setTitle("INGRESO DE DATOS DE EXPANSION");
        ventIn.setResizable(false);
        ventIn.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        ventIn.setVisible(true);
    }//GEN-LAST:event_jIngresarExpansionItemActionPerformed

    private void jMostrarJuegosItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMostrarJuegosItemActionPerformed
        MostrarJuego ventMO=new MostrarJuego();
        ventMO.setLocationRelativeTo(null);
        ventMO.setTitle("MOSTRANDO DATOS DE LOS JUEGO");
        ventMO.setResizable(false);
        ventMO.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        ventMO.setVisible(true);
    }//GEN-LAST:event_jMostrarJuegosItemActionPerformed

    private void jMostrarExpansionItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMostrarExpansionItemActionPerformed
        MostrarExpansion ventMO=new MostrarExpansion();
        ventMO.setLocationRelativeTo(null);
        ventMO.setTitle("MOSTRANDO DATOS DE LAS EXPANSIONES");
        ventMO.setResizable(false);
        ventMO.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        ventMO.setVisible(true);
    }//GEN-LAST:event_jMostrarExpansionItemActionPerformed

    private void btnStockjuegosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStockjuegosActionPerformed
        JuegoDAO jueDAO= new JuegoDAO();
        JOptionPane.showMessageDialog(null,"El stock total de juegos es: "+jueDAO.totalStock()); 
    }//GEN-LAST:event_btnStockjuegosActionPerformed

    private void btnStockexpansionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStockexpansionesActionPerformed
        ExpansionDAO expaDAO= new ExpansionDAO();
         JOptionPane.showMessageDialog(null,"El stock total de expansiones es: "+expaDAO.totalExpansiones());
    }//GEN-LAST:event_btnStockexpansionesActionPerformed

    private void jSalirAplicacionItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jSalirAplicacionItemActionPerformed
        dispose();
    }//GEN-LAST:event_jSalirAplicacionItemActionPerformed
 
    
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu InformacionMenu;
    private javax.swing.JMenu IngresarMenu;
    private javax.swing.JMenuBar MenuBar1;
    private javax.swing.JMenu SalirMenu;
    private javax.swing.JMenuItem btnStockexpansiones;
    private javax.swing.JMenuItem btnStockjuegos;
    private javax.swing.JMenu btnStocktotalEX;
    private javax.swing.JMenuItem jIngresarExpansionItem;
    private javax.swing.JMenuItem jIngresarJuegoItem;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenuItem jMostrarExpansionItem;
    private javax.swing.JMenuItem jMostrarJuegosItem;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JMenuItem jSalirAplicacionItem;
    // End of variables declaration//GEN-END:variables
}
