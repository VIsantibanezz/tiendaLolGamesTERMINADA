package modelo;
public class Juego extends TiendaLolGames{
    public String tipoJuego, marca;

    public Juego(String tipoJuego, String marca, String nombre, String codigo, int stock) {
        super(nombre, codigo, stock);
        this.tipoJuego = tipoJuego;
        this.marca = marca;
    }

    public String getTipoJuego() {
        return tipoJuego;
    }

    public String getMarca() {
        return marca;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCodigo() {
        return codigo;
    }

    public int getStock() {
        return stock;
    }

    public void setTipoJuego(String tipoJuego) {
        this.tipoJuego = tipoJuego;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }
    
   

    

    
    
}
