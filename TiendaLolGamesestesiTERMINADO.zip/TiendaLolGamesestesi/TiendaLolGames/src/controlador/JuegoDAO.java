package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.Juego;

public class JuegoDAO {
    public Juego buscarJuego(String cod){
        Juego ju=null;
        try{
            Connection con=Conexion.getConexion();
            String query="select * from juego where codigo='"+cod+"'";
            PreparedStatement ps=con.prepareStatement(query);
            
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                ju=new Juego(rs.getString(3), rs.getString(4), rs.getString(2), rs.getString(1), rs.getInt(5));
            }
            ps.close();
            
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(JuegoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ju;
    }
    public boolean ingresarJuego(Juego ju){
        
        boolean resultado = false;
        try{
            Connection con = Conexion.getConexion();
            String query= "insert into juego (Codigo,Nombre,TipoDeJuego,Marca,Stock) values(?,?,?,?,?) ";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, ju.getCodigo());
            ps.setString(2, ju.getNombre());
            ps.setString(3, ju.getTipoJuego());
            ps.setString(4, ju.getMarca());
            ps.setInt(5, ju.getStock());

            resultado = ps.executeUpdate() == 1;
            ps.close();
        }   catch (SQLException | ClassNotFoundException ex) {
                Logger.getLogger(JuegoDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        return resultado;
    
    }
    public boolean modificarJuego(Juego ju){
        boolean resultado = false;
        try{
            Connection con = Conexion.getConexion();
            String query= "update juego set  Nombre=?,TipoDeJuego=?,Marca=?,Stock=? where Codigo=?";
            PreparedStatement ps = con.prepareStatement(query);
            
            ps.setString(1, ju.getNombre());
            ps.setString(2, ju.getTipoJuego());
            ps.setString(3, ju.getMarca());
            ps.setInt(4, ju.getStock());
            ps.setString(5, ju.getCodigo());
            
            resultado = ps.executeUpdate() == 1;
            ps.close();

        }   catch (SQLException | ClassNotFoundException ex) {
                Logger.getLogger(JuegoDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        return resultado;
    
    }
    
    public boolean eliminarJuego(String codigo){
        boolean resultado = false;
        try{
            Connection con = Conexion.getConexion();
            String query= "delete from juego where Codigo = '"+codigo+"'";
            PreparedStatement ps = con.prepareStatement(query);
            
            resultado = ps.executeUpdate()== 1;
            ps.close();
            
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(JuegoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return resultado;
    }
    
    public ArrayList<Juego> todosLosJuegos(){
        ArrayList<Juego> ju=new ArrayList();
        try{
            Connection con=Conexion.getConexion();
            String query="Select * from juego";
            PreparedStatement ps=con.prepareStatement(query);
            ResultSet rs=ps.executeQuery();
            Juego jue;
            
            while(rs.next()){
                jue=new Juego(rs.getString(3), rs.getString(4), rs.getString(2), rs.getString(1), rs.getInt(5));
                ju.add(jue);
            }
            ps.close();
            
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(JuegoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ju;
        
        
    }
    
    public int totalStock(){
        int resultado = 0;
        
        try{
            Connection con=Conexion.getConexion();
            String query="Select SUM(Stock) as totalStockJuegos from juego  ";
            PreparedStatement ps=con.prepareStatement(query);
            ResultSet rs=ps.executeQuery();
            
            if(rs.next()){
                resultado = rs.getInt("totalStockJuegos");
            }
            
            ps.close();
           
                   
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(JuegoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return resultado;
    }
   
    
}
