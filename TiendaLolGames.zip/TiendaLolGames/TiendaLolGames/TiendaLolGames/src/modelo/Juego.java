package modelo;
public class Juego extends TiendaLolGames{
    public String tipoJuego, marca;
    int valor;

    public Juego(int valor, String nombre, String codigo, int stock) {
        super(nombre, codigo, stock);
        this.valor = valor;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }
    

    public Juego(String tipoJuego, String marca, String nombre, String codigo, int stock) {
        super(nombre, codigo, stock);
        this.tipoJuego = tipoJuego;
        this.marca = marca;
    }

    public String getTipoJuego() {
        return tipoJuego;
    }

    public String getMarca() {
        return marca;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCodigo() {
        return codigo;
    }

    public int getStock() {
        return stock;
    }

    public void setTipoJuego(String tipoJuego) {
        this.tipoJuego = tipoJuego;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }
    
    @Override
    public int totalTipoJuego() {
        int valor=0;
      if(tipoJuego.compareToIgnoreCase("Cartas")==0)
          return valor=10000;
      if(tipoJuego.compareToIgnoreCase("Puzle")==0)
          return valor=15000;
      if(tipoJuego.compareToIgnoreCase("Rompe cabez")==0)
          return valor=5000;
      if(tipoJuego.compareToIgnoreCase("Cooperativo")==0)
          return valor=40000;
      return valor;
    }

   

    
        
}
