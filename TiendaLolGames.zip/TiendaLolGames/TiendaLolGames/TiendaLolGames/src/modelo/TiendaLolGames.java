
package modelo;


public abstract class TiendaLolGames 
{
    public String nombre, codigo;
    public int stock;

    

    public TiendaLolGames(String nombre, String codigo, int stock) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.stock = stock;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCodigo() {
        return codigo;
    }

    public int getStock() {
        return stock;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }
    
    public abstract int totalTipoJuego();
   
    
    
    

}
