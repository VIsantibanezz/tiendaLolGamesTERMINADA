package modelo;
public class Expansion extends TiendaLolGames{
        private String juegoP;
        private String masJugadores;
        

    public Expansion(String juegoP, String masJugadores, String nombre, String codigo, int stock) {
        super(nombre, codigo, stock);
        this.juegoP = juegoP;
        this.masJugadores = masJugadores;
    }

    public String getJuegoP() {
        return juegoP;
    }

    public String getMasJugadores() {
        return masJugadores;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCodigo() {
        return codigo;
    }

    public int getStock() {
        return stock;
    }

    public void setJuegoP(String juegoP) {
        this.juegoP = juegoP;
    }

    public void setMasJugadores(String masJugadores) {
        this.masJugadores = masJugadores;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    @Override
    public int totalTipoJuego() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    

   
    
    
        
        

    
   

    
        
}
