package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.Expansion;
import modelo.Juego;

public class ExpansionDAO {
    public Expansion buscarExpansion(String cod){
        Expansion ex=null;
        try{
            Connection con=Conexion.getConexion();
            String query="select * from expansion where codigo='"+cod+"'";
            PreparedStatement ps=con.prepareStatement(query);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                ex= new Expansion(rs.getString(3), rs.getString(4), rs.getString(2), rs.getString(1), rs.getInt(5));
            }
            ps.close();
        } catch (SQLException | ClassNotFoundException ex1) {
            Logger.getLogger(ExpansionDAO.class.getName()).log(Level.SEVERE, null, ex1);
        }
        return ex;
    }
    
    public boolean ingresarExpansion(Expansion ex){
        boolean resultado = false;
        try{
            Connection con = Conexion.getConexion();
            String query= "insert into expansion (Codigo,Nombre,JuegoPerteneciente,AgregaJugadores,Stock) values(?,?,?,?,?) ";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, ex.getCodigo());
            ps.setString(2, ex.getNombre());
            ps.setString(3, ex.getJuegoP());
            ps.setString(4, ex.getMasJugadores());
            ps.setInt(5, ex.getStock());
            
            System.out.println(ps);
            resultado = ps.executeUpdate() == 1;
            ps.close();
            
        } catch (SQLException | ClassNotFoundException ex1) {
            Logger.getLogger(ExpansionDAO.class.getName()).log(Level.SEVERE, null, ex1);
        }
        return resultado;
    }
    public boolean modificarExpansion(Expansion ex){
        boolean resultado = false;
        try{
            Connection con = Conexion.getConexion();
            String query= "update expansion set  Nombre = ?, JuegoPerteneciente = ?, AgregaJugadores = ?, Stock = ? where Codigo = ?";
            PreparedStatement ps = con.prepareStatement(query);
            
            ps.setString(1, ex.getNombre());
            ps.setString(2, ex.getJuegoP());
            ps.setString(3, ex.getMasJugadores());
            ps.setInt(4, ex.getStock());
            ps.setString(5, ex.getCodigo());
            System.out.println(ps);
            resultado = ps.executeUpdate() == 1;
            ps.close();
            
        } catch (SQLException | ClassNotFoundException ex1) {
            Logger.getLogger(ExpansionDAO.class.getName()).log(Level.SEVERE, null, ex1);
        }
        return resultado;
    }
    
    public boolean eliminarExpansion(String codigo){
        boolean resultado = false;
        try{
            Connection con = Conexion.getConexion();
            String query= "delete from expansion where Codigo = '"+codigo+"'";
            PreparedStatement ps = con.prepareStatement(query);
            
            resultado = ps.executeUpdate()== 1;
            ps.close();
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(ExpansionDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return resultado;
    }
    
    public ArrayList<Expansion> todasExpansiones(){
        
        ArrayList<Expansion> ex=new ArrayList();
        try{
            Connection con=Conexion.getConexion();
            String query="Select * from expansion";
            PreparedStatement ps=con.prepareStatement(query);
            ResultSet rs=ps.executeQuery();
            Expansion exp;
            
            while(rs.next()){
                
                exp= new Expansion(rs.getString(3), rs.getString(4), rs.getString(2), rs.getString(1), rs.getInt(5));
                ex.add(exp);
            }
            ps.close();
        } catch (SQLException | ClassNotFoundException ex1) {
            Logger.getLogger(ExpansionDAO.class.getName()).log(Level.SEVERE, null, ex1);
        }
        return ex;

    }
     public int totalExpansiones(){
        int resultado = 0;
        
        try{
            Connection con=Conexion.getConexion();
            String query="Select SUM(Stock) as totalStockExpansiones from expansion  ";
            PreparedStatement ps=con.prepareStatement(query);
            ResultSet rs=ps.executeQuery();
            
            if(rs.next()){
                resultado = rs.getInt("totalStockExpansiones");
            }
            
            ps.close();
           
                   
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(ExpansionDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return resultado;
    }
}
