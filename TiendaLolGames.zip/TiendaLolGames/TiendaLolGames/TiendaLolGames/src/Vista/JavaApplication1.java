
package Vista;

import static javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE;

public class JavaApplication1 {

    
    public static void main(String[] args) 
    {
        
        
       Ingresar ventPrin=new Ingresar();
       ventPrin.setLocationRelativeTo(null);
       ventPrin.setTitle("MENU PRINCIPAL");
       ventPrin.setResizable(false);
       ventPrin.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
       ventPrin.setVisible(true);
    }
    
}
